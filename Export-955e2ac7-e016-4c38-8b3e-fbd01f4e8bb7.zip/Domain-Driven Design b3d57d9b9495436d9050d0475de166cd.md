# Domain-Driven Design

![ddd.png](Domain-Driven%20Design%20b3d57d9b9495436d9050d0475de166cd/ddd.png)

## Paradigms

[Ubiquitous Language](https://www.notion.so/Ubiquitous-Language-6cabe99250594702bc143348e5a5a4c7)

[Model-Driven Design](https://www.notion.so/Model-Driven-Design-bdbbe2e388824bf782247ba7e19e02dc)

[Hands-On Modelers](https://www.notion.so/Hands-On-Modelers-ff10e0dd8aaf4c5382e5b3fb060e2d49)

[Layered Architecture](https://www.notion.so/Layered-Architecture-07fafa0991704cb7aa56560d96c19d8d)

[Smart UI Anti-Pattern](https://www.notion.so/Smart-UI-Anti-Pattern-08c332b051d74cc3aff08c313aff8d24)

## Building Blocks

[Entities](https://www.notion.so/Entities-85d09d93de174aad888ffc5f030edf81)

[Value Objects](https://www.notion.so/Value-Objects-3e4d31b80e94402383e962c163c9125d)

[Services](https://www.notion.so/Services-7e07a825e4004d14b16f32e9f9fdfec2)

[Modules](https://www.notion.so/Modules-1122b1a705b8475496ab16580be8e8cd)

[Aggregates](https://www.notion.so/Aggregates-51aeb13f64604cbe966d55b05cb5c04f)

[Factories](https://www.notion.so/Factories-3f023bdfc4ab4aa0b57375befb36129a)

[Repositories](https://www.notion.so/Repositories-0dca363f435a47e69201cb37ff68770e)

## Supple Design

[Intention-Revealing Interfaces](https://www.notion.so/Intention-Revealing-Interfaces-d78e7e7ab50e4bafb79282bd3e5e9d45)

[Side-Effect-Free Functions](https://www.notion.so/Side-Effect-Free-Functions-33cab60175354735b78e5780b9b9b580)

[Assertions](https://www.notion.so/Assertions-142f34f5a8ea4adaa4461e845a4ff42b)

[Conceptual Contours](https://www.notion.so/Conceptual-Contours-2efbd5416eaa4b25af208af7119359b7)

[Standalone Classes](https://www.notion.so/Standalone-Classes-af6673cf49aa4b619edd3ba334bfaabd)

[Closure of Operations](https://www.notion.so/Closure-of-Operations-e2da68915c6b443fa930987737b63c1e)

## Design Patterns

[Strategy](https://www.notion.so/Strategy-6d3efbab7f5c4398a87fd6a827c53c9c)

[Composite](https://www.notion.so/Composite-9d894368a5dd49a4921dc22476dd8fc8)

## Context

[Bounded Context](https://www.notion.so/Bounded-Context-79356f82b0654b3daaea67efacbd0d41)

[Continuous Integration](https://www.notion.so/Continuous-Integration-578565c46a9c4a6a85847ceb2d6eaa0b)

[Context Map](https://www.notion.so/Context-Map-3984e3925cb440999eb13dd91778deb1)

## Distillation

[Core Domain](https://www.notion.so/Core-Domain-acfbffaf525a4a42b5c8da208e8024d4)

[Generic Subdomains](https://www.notion.so/Generic-Subdomains-421ee75f7d774b8c8081f5f178944524)

[Domain Vision Statement](https://www.notion.so/Domain-Vision-Statement-f6b205f582e543ab9f14aaa090d28c8b)

## Large-Scale Structure

[Evolving Order](https://www.notion.so/Evolving-Order-5e522dec0d034932a9736f7347e5ab29)